using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Move sets", fileName = "Move set", order = 1)]
public class MoveSet : ScriptableObject
{
   
}
