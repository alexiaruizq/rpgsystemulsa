public enum JobsOptions
{
  MAGE,
  ARCHER,
  WARRIOR
}