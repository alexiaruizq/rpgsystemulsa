using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mage : CharacterJob
{
  public override void Fire()
  {
    base.Fire();
  }
}
