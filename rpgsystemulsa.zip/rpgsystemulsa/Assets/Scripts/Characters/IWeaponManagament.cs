public interface IWeaponeManagament
{
    void ChangeWeapon(int weaponIndex);
    void ChangeWeapon(string weaponName);

}