public interface IConsumable
{
    void consume();
    
}