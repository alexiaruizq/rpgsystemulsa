public interface IHostile
{
    void Attack();
    int GetDamage();
}